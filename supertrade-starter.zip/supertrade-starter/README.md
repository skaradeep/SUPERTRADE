# SUPERTRADE starter — Copy Trading first

This is the first runnable foundation for the SUPERTRADE web app. It includes a polished mobile-first landing page, copy-trading onboarding UI, Supabase email/password auth, and an admin content editor for tutorial URLs, action links and instructions.

**This is not yet a deployed live site.** It needs your own Supabase project and hosting deployment. The app can be previewed in demo mode before Supabase is connected, but demo edits are not saved permanently.

## Run in Replit

1. Create a new Replit app using a **React / TypeScript** template, or upload/extract this project into a Replit workspace.
2. Open the Shell and run:
   ```bash
   npm install
   npm run dev
   ```
3. For a production build, run `npm run build`.

If Replit generated a different starter project, upload these project files into a new workspace rather than overwriting any important work.

## Connect Supabase

1. Create a Supabase project at https://supabase.com/dashboard.
2. In Supabase, open **Project Settings → API Keys** (menu labels may vary).
3. Copy the Project URL and the **publishable** key (or legacy public `anon` key). Never use `service_role` or `sb_secret_` in the frontend.
4. Add these as Replit Secrets / environment variables:
   - `VITE_SUPABASE_URL` = your project URL
   - `VITE_SUPABASE_ANON_KEY` = your publishable/public anon key
5. In Supabase **SQL Editor**, run the complete contents of `supabase/schema.sql`.
6. Register your owner account through the app and confirm the email if email confirmation is enabled.
7. In Supabase SQL Editor, run the final admin-grant statement from the bottom of `schema.sql`, replacing `YOUR_OWNER_EMAIL` with your exact email address. Do this only for an account you control.
8. Restart the Replit app so the environment variables load.

The public/publishable key is intended for browser apps when RLS is configured correctly. Never paste a service-role or secret key into Replit frontend environment variables.

## What is included

- Premium navy / electric-blue starter UI
- Copy-trading onboarding steps
- Editable video URL, action URL, instructions, display order and publish state
- Supabase authentication
- Supabase schema with RLS
- Admin-only editing policy
- Member-visible published steps
- Demo mode before database configuration

## Not included yet

- The original SkaraDeep white-beanie photograph or official logo (not included in this chat's files; add your own asset once available)
- Manual EFT proof-of-payment and admin payment queue
- Signals purchases and per-group entitlements
- Internet Money Cartel programme
- Mentorship bookings and live video
- Full community chat and partner commissions
- Live broker/copy-trading API integration
- Deployment / custom domain

These are planned follow-on stages. Do not collect real payments or invite members until access controls and any paid features have been fully implemented and tested.
