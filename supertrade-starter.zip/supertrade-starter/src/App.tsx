import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { Activity, ArrowLeft, ArrowUpRight, BookOpen, Check, ChevronRight, CircleHelp, ExternalLink, Eye, EyeOff, FileVideo, Globe, LayoutDashboard, Link as LinkIcon, LogIn, LogOut, Menu, Pencil, PlayCircle, Plus, Save, Settings2, ShieldCheck, Sparkles, UserRound, Video, Wallet, X } from 'lucide-react';
import { supabase, supabaseConfigured, type OnboardingStep } from './supabase';

type Profile = { id: string; email?: string; role?: string };
const initialSteps: OnboardingStep[] = [
  { id:'register', title:'Create your broker account', description:'Register with the broker using the official link provided here.', video_url:'', action_label:'Open registration', action_url:'', guide_text:'Use the registration link below. If you already have an account, continue to the next step and follow the existing-account instructions.', position:1, is_published:true },
  { id:'fund', title:'How to fund your account', description:'Follow the funding guide before making a deposit.', video_url:'', action_label:'Open funding page', action_url:'', guide_text:'Check the broker’s minimum deposit and account type before sending money. Deposits go directly to your broker, not SUPERTRADE.', position:2, is_published:true },
  { id:'connect', title:'Connect to copy trading', description:'Watch the tutorial and follow each step to link your account.', video_url:'', action_label:'Open copy trading', action_url:'', guide_text:'Follow the copy-trading provider’s official instructions. Confirm account details and risk settings before enabling copying.', position:3, is_published:true },
  { id:'withdraw', title:'Withdrawals and account support', description:'Find withdrawal guidance and know where to ask for help.', video_url:'', action_label:'Open withdrawal guide', action_url:'', guide_text:'Review the broker’s withdrawal rules and fees. SUPERTRADE does not hold client trading funds.', position:4, is_published:true }
];

function validUrl(value: string) { if (!value.trim()) return true; try { const u = new URL(value); return u.protocol === 'https:' || u.protocol === 'http:'; } catch { return false; } }
function Brand({ small = false }: { small?: boolean }) { return <div className={`brand ${small ? 'brand-small' : ''}`}><div className="brand-mark"><Activity size={small ? 18 : 22}/></div><div><div className="brand-name">SUPERTRADE<span>®</span></div><div className="brand-tag">LED BY SKARADEEP</div></div></div>; }
function App() {
  const [page, setPage] = useState<'home'|'copy'|'admin'>('home');
  const [steps, setSteps] = useState<OnboardingStep[]>(initialSteps);
  const [activeStep, setActiveStep] = useState<OnboardingStep | null>(null);
  const [user, setUser] = useState<Profile | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login'|'signup'>('signup');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState<OnboardingStep | null>(null);
  const [saving, setSaving] = useState(false);
  const [adminMode, setAdminMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [dbStatus, setDbStatus] = useState(supabaseConfigured ? 'Connecting to Supabase…' : 'Preview mode · database not connected');

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(async ({ data }) => {
      if (data.session?.user) await loadProfile(data.session.user.id, data.session.user.email ?? '');
      else setDbStatus('Connected · sign in to access your account');
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) { setUser(null); setAdminMode(false); }
      else { void loadProfile(session.user.id, session.user.email ?? ''); }
    });
    void loadSteps();
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadProfile(id: string, userEmail: string) {
    if (!supabase) return;
    const { data, error } = await supabase.from('profiles').select('id, role').eq('id', id).maybeSingle();
    setUser({ id, email: userEmail, role: data?.role ?? 'member' });
    setDbStatus(error ? 'Signed in · profile setup needed' : 'Connected to Supabase');
  }
  async function loadSteps() {
    if (!supabase) return;
    const { data, error } = await supabase.from('onboarding_steps').select('*').order('position');
    if (!error && data && data.length) setSteps(data as OnboardingStep[]);
  }
  const isAdmin = user?.role === 'admin';
  const visibleSteps = useMemo(() => steps.filter(s => s.is_published).sort((a,b)=>a.position-b.position), [steps]);

  async function handleAuth(e: FormEvent) {
    e.preventDefault(); setBusy(true); setNotice('');
    try {
      if (!supabase) { setNotice('First connect Supabase using the setup guide in README.md. Preview mode cannot create real accounts.'); return; }
      if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setNotice('Check your email to confirm your account, then sign in.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setAuthOpen(false); setNotice('You are signed in.');
      }
    } catch (err) { setNotice(err instanceof Error ? err.message : 'Something went wrong.'); }
    finally { setBusy(false); }
  }
  async function signOut() { if (supabase) await supabase.auth.signOut(); setUser(null); setPage('home'); setAdminMode(false); }
  async function saveStep(e: FormEvent) {
    e.preventDefault(); if (!editing) return;
    if (!validUrl(editing.video_url) || !validUrl(editing.action_url)) { setNotice('Use a valid http:// or https:// link.'); return; }
    setSaving(true); setNotice('');
    try {
      if (supabase && isAdmin) {
        const payload = { title:editing.title, description:editing.description, video_url:editing.video_url, action_label:editing.action_label, action_url:editing.action_url, guide_text:editing.guide_text, position:editing.position, is_published:editing.is_published };
        const { data, error } = await supabase.from('onboarding_steps').upsert({ id:editing.id, ...payload }).select().single();
        if (error) throw error;
        setSteps(old => [...old.filter(s=>s.id!==editing.id), data as OnboardingStep].sort((a,b)=>a.position-b.position));
        setNotice('Changes saved to the database.');
      } else if (!supabaseConfigured) {
        setSteps(old => [...old.filter(s=>s.id!==editing.id), editing].sort((a,b)=>a.position-b.position));
        setNotice('Preview updated in this session only. Connect Supabase to save changes permanently.');
      } else { setNotice('Sign in with an authorised admin account to save changes.'); }
      setEditing(null);
    } catch (err) { setNotice(err instanceof Error ? err.message : 'Could not save changes.'); }
    finally { setSaving(false); }
  }
  function startEdit(step: OnboardingStep) { setEditing({ ...step }); }
  function newStep() { setEditing({ id: crypto.randomUUID(), title:'New onboarding step', description:'', video_url:'', action_label:'Open guide', action_url:'', guide_text:'', position:steps.length+1, is_published:false }); }

  return <div className="app-shell">
    <header className="topbar"><button className="mobile-menu icon-btn" onClick={()=>setMenuOpen(v=>!v)} aria-label="Open menu"><Menu/></button><button className="brand-button" onClick={()=>setPage('home')}><Brand small/></button><nav className={menuOpen?'nav nav-open':'nav'}><button className={page==='home'?'nav-link active':'nav-link'} onClick={()=>{setPage('home');setMenuOpen(false)}}>Overview</button><button className={page==='copy'?'nav-link active':'nav-link'} onClick={()=>{setPage('copy');setMenuOpen(false)}}>Copy trading</button>{isAdmin&&<button className={page==='admin'?'nav-link active':'nav-link'} onClick={()=>{setPage('admin');setMenuOpen(false)}}>Admin studio</button>}</nav><div className="top-actions">{user ? <><span className="user-chip"><span className="online-dot"/>{user.email?.split('@')[0]}</span><button className="icon-btn" onClick={signOut} title="Sign out"><LogOut size={17}/></button></> : <button className="btn btn-quiet btn-small" onClick={()=>{setAuthMode('login');setAuthOpen(true)}}><LogIn size={15}/> Sign in</button>}<button className="avatar" onClick={()=>{if(!user){setAuthMode('signup');setAuthOpen(true)}else setPage(isAdmin?'admin':'copy')}} aria-label="Account"><UserRound size={17}/></button></div></header>

    <main>
      {page==='home' && <>
        <section className="hero"><div className="hero-grid"/><div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> YOUR TRADING JOURNEY STARTS HERE</div><h1>Move with a plan.<br/><span>Trade with purpose.</span></h1><p className="hero-description">Your home for copy-trading guidance, education and a community built around growth.</p><div className="hero-buttons"><button className="btn btn-primary" onClick={()=>setPage('copy')}>Start copy trading <ArrowUpRight size={17}/></button><button className="btn btn-ghost" onClick={()=>{setAuthMode('signup');setAuthOpen(true)}}>Create free account <ChevronRight size={17}/></button></div><div className="hero-proof"><span><ShieldCheck size={15}/> Guided onboarding</span><span><Globe size={15}/> Built for mobile</span></div></div><div className="hero-visual"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-glow"/><div className="hero-emblem"><div className="emblem-lines"><Activity size={72} strokeWidth={1.3}/></div><div className="emblem-caption">SUPERTRADE</div><div className="emblem-sub">LED BY SKARADEEP</div></div><div className="floating-card floating-card-top"><span className="status-dot"/> MEMBER ONBOARDING <strong>Made simple</strong></div><div className="floating-card floating-card-bottom"><div className="mini-icon"><PlayCircle size={17}/></div><div><small>YOUR NEXT STEP</small><strong>Learn how to connect</strong></div><ChevronRight size={16}/></div></div></section>
        <section className="feature-row"><div className="section-heading"><div><div className="eyebrow">THE PLATFORM</div><h2>Everything starts with <span>clarity.</span></h2></div><p>Simple tools. Clear steps. One place to get started.</p></div><div className="feature-grid"><button className="feature-card" onClick={()=>setPage('copy')}><div className="feature-icon blue"><Activity/></div><div className="feature-meta">01 / GET STARTED</div><h3>Copy trading</h3><p>Follow clear setup guides, watch tutorials and open the links you need.</p><span className="feature-link">Start setup <ArrowUpRight size={16}/></span></button><div className="feature-card muted-card"><div className="feature-icon violet"><BookOpen/></div><div className="feature-meta">02 / LEARN</div><h3>Education</h3><p>Learning resources and live-class features can be added in the next build stage.</p><span className="coming-soon">COMING NEXT</span></div><div className="feature-card muted-card"><div className="feature-icon cyan"><UserRound/></div><div className="feature-meta">03 / CONNECT</div><h3>Community</h3><p>A moderated member community is planned for the next build stage.</p><span className="coming-soon">COMING NEXT</span></div></div></section>
      </>}

      {page==='copy' && <section className="content-page"><button className="back-link" onClick={()=>setPage('home')}><ArrowLeft size={15}/> Back to overview</button><div className="page-intro"><div className="eyebrow"><Activity size={14}/> COPY TRADING ONBOARDING</div><h1>Let's get you <span>connected.</span></h1><p>Follow each step at your own pace. Use the official links and check the instructions before taking action.</p></div><div className="onboarding-layout"><div className="steps-list"><div className="list-top"><div><h2>Your setup guide</h2><p>{visibleSteps.length} steps to work through</p></div><span className="secure-label"><ShieldCheck size={14}/> Guided</span></div>{visibleSteps.length===0 && <div className="empty-state">No published steps yet. Please check back soon.</div>}{visibleSteps.map((step,index)=><button key={step.id} className={`step-row ${activeStep?.id===step.id?'step-selected':''}`} onClick={()=>setActiveStep(step)}><div className="step-number">{String(index+1).padStart(2,'0')}</div><div className="step-text"><strong>{step.title}</strong><span>{step.description}</span></div><ChevronRight size={18}/></button>)}</div><div className="step-detail">{activeStep ? <><div className="detail-top"><div className="detail-icon"><FileVideo size={21}/></div><span className="detail-label">STEP {String(visibleSteps.findIndex(s=>s.id===activeStep.id)+1).padStart(2,'0')}</span></div><h2>{activeStep.title}</h2><p>{activeStep.description}</p>{activeStep.video_url && <a className="video-preview" href={activeStep.video_url} target="_blank" rel="noreferrer"><div className="video-play"><PlayCircle size={31}/></div><div><small>VIDEO TUTORIAL</small><strong>Watch this step</strong></div><ExternalLink size={16}/></a>}<div className="guide-box"><div className="guide-title"><BookOpen size={16}/> What to do</div><p>{activeStep.guide_text || 'Follow the instructions and review all details before continuing.'}</p></div>{activeStep.action_url && <a className="btn btn-primary full-btn" href={activeStep.action_url} target="_blank" rel="noreferrer">{activeStep.action_label || 'Open link'} <ArrowUpRight size={17}/></a>}{!activeStep.action_url && <div className="link-pending"><LinkIcon size={16}/> Link will appear here once configured by the team.</div>}<div className="risk-note"><ShieldCheck size={17}/><span>Trading involves risk and losses are possible. SUPERTRADE does not hold your broker funds. Never share your password or one-time codes.</span></div></> : <div className="select-step"><div className="detail-icon"><PlayCircle size={25}/></div><h2>Select your first step</h2><p>Choose a step from the list to see its instructions, video and official link.</p></div>}</div></div></section>}

      {page==='admin' && <section className="content-page"><button className="back-link" onClick={()=>setPage('home')}><ArrowLeft size={15}/> Back to overview</button><div className="page-intro"><div className="eyebrow"><Settings2 size={14}/> CONTROL CENTRE</div><h1>Admin <span>studio.</span></h1><p>Manage the copy-trading steps and publish updated links without changing the app code.</p></div>{!isAdmin ? <div className="permission-card"><ShieldCheck size={27}/><h2>Admin access required</h2><p>Sign in with an account whose role has been securely assigned as admin in Supabase. This page cannot grant itself admin access.</p><button className="btn btn-primary" onClick={()=>{setAuthMode('login');setAuthOpen(true)}}>Sign in <LogIn size={16}/></button></div> : <><div className="admin-summary"><div><span>ONBOARDING STEPS</span><strong>{steps.length}</strong></div><div><span>PUBLISHED</span><strong>{steps.filter(s=>s.is_published).length}</strong></div><div><span>STATUS</span><strong className="status-live">Connected</strong></div></div><div className="admin-list"><div className="admin-list-header"><div><h2>Copy trading content</h2><p>Update titles, tutorials, links and instructions.</p></div><button className="btn btn-primary btn-small" onClick={newStep}><Plus size={16}/> Add step</button></div>{steps.sort((a,b)=>a.position-b.position).map((step,index)=><div className="admin-item" key={step.id}><div className="admin-item-icon"><Video size={19}/></div><div className="admin-item-info"><strong>{step.title}</strong><span>{step.video_url?'Video added':'No video URL'} · {step.action_url?'Link configured':'Link not set'}</span></div><span className={step.is_published?'published-tag':'draft-tag'}>{step.is_published?'Published':'Draft'}</span><button className="icon-btn edit-btn" onClick={()=>startEdit(step)} aria-label="Edit step"><Pencil size={16}/></button></div>)}</div></>}</section>}
    </main>
    <footer className="footer"><Brand small/><span>Trading involves risk. No profits are guaranteed.</span><span className="db-status"><span className={supabaseConfigured?'status-dot':'status-dot status-demo'}/>{dbStatus}</span></footer>

    {authOpen && <div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="modal auth-modal" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setAuthOpen(false)}><X size={19}/></button><Brand/><div className="modal-heading"><h2>{authMode==='signup'?'Create your account':'Welcome back'}</h2><p>{authMode==='signup'?'Join SUPERTRADE for free.':'Sign in to continue to your workspace.'}</p></div><form onSubmit={handleAuth} className="form-stack"><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required autoComplete="email"/></label><label>Password<div className="password-wrap"><input type={showPassword?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters" required minLength={8} autoComplete={authMode==='signup'?'new-password':'current-password'}/><button type="button" className="password-toggle" onClick={()=>setShowPassword(v=>!v)}>{showPassword?<EyeOff size={16}/>:<Eye size={16}/>}</button></div></label><button className="btn btn-primary full-btn" disabled={busy}>{busy?'Please wait…':authMode==='signup'?'Create free account':'Sign in'} <ChevronRight size={17}/></button></form>{notice&&<div className="notice"><CircleHelp size={16}/>{notice}</div>}<p className="switch-auth">{authMode==='signup'?'Already have an account?':'New to SUPERTRADE?'} <button onClick={()=>{setAuthMode(authMode==='signup'?'login':'signup');setNotice('')}}>{authMode==='signup'?'Sign in':'Create an account'}</button></p>{!supabaseConfigured&&<div className="demo-warning">Preview mode: real registration becomes available after Supabase is connected.</div>}</div></div>}

    {editing && <div className="modal-backdrop" onClick={()=>setEditing(null)}><div className="modal editor-modal" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setEditing(null)}><X size={19}/></button><div className="eyebrow"><Pencil size={14}/> EDIT CONTENT</div><h2>{editing.id==='register'||editing.id==='fund'||editing.id==='connect'||editing.id==='withdraw'?'Edit onboarding step':'New onboarding step'}</h2><p className="modal-subtitle">Published changes are shown to members on the Copy Trading page.</p><form onSubmit={saveStep} className="form-stack"><label>Step title<input value={editing.title} onChange={e=>setEditing({...editing,title:e.target.value})} required/></label><label>Short description<textarea value={editing.description} onChange={e=>setEditing({...editing,description:e.target.value})} rows={2}/></label><label>Video tutorial URL<input type="url" value={editing.video_url} onChange={e=>setEditing({...editing,video_url:e.target.value})} placeholder="https://youtube.com/watch?v=..."/></label><label>Action button text<input value={editing.action_label} onChange={e=>setEditing({...editing,action_label:e.target.value})} placeholder="Open registration"/></label><label>Action link URL<input type="url" value={editing.action_url} onChange={e=>setEditing({...editing,action_url:e.target.value})} placeholder="https://..."/></label><label>Written instructions<textarea value={editing.guide_text} onChange={e=>setEditing({...editing,guide_text:e.target.value})} rows={4}/></label><label>Display order<input type="number" min="1" value={editing.position} onChange={e=>setEditing({...editing,position:Number(e.target.value)})}/></label><label className="checkbox-label"><input type="checkbox" checked={editing.is_published} onChange={e=>setEditing({...editing,is_published:e.target.checked})}/> Publish this step to members</label><button className="btn btn-primary full-btn" disabled={saving}><Save size={16}/>{saving?'Saving…':'Save changes'}</button></form>{notice&&<div className="notice"><CircleHelp size={16}/>{notice}</div>}</div></div>}
  </div>;
}

export default App;
