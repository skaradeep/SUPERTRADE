import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabaseConfigured = Boolean(url && key && !url.includes('YOUR_PROJECT_REF') && !key.includes('YOUR_SUPABASE'));
export const supabase = supabaseConfigured ? createClient(url!, key!) : null;

export type OnboardingStep = {
  id: string;
  title: string;
  description: string;
  video_url: string;
  action_label: string;
  action_url: string;
  guide_text: string;
  position: number;
  is_published: boolean;
};
