-- SUPERTRADE starter schema. Run this in Supabase SQL Editor after creating your project.
-- This schema intentionally keeps role changes admin-controlled.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'member' check (role in ('member','admin','partner')),
  created_at timestamptz not null default now()
);

create table if not exists public.onboarding_steps (
  id text primary key,
  title text not null,
  description text not null default '',
  video_url text not null default '',
  action_label text not null default 'Open link',
  action_url text not null default '',
  guide_text text not null default '',
  position integer not null default 1,
  is_published boolean not null default false,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);

alter table public.profiles enable row level security;
alter table public.onboarding_steps enable row level security;

-- A user can read their own profile only. They cannot update their own role.
drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);

-- Create profile rows automatically at signup. Role is always member by default.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'member')
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_supertrade_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

-- Members can read only published onboarding steps; admins can manage all steps.
drop policy if exists "Published steps readable by everyone" on public.onboarding_steps;
create policy "Published steps readable by everyone" on public.onboarding_steps for select to anon, authenticated using (is_published = true or public.is_supertrade_admin());
drop policy if exists "Admins insert onboarding steps" on public.onboarding_steps;
create policy "Admins insert onboarding steps" on public.onboarding_steps for insert to authenticated with check (public.is_supertrade_admin());
drop policy if exists "Admins update onboarding steps" on public.onboarding_steps;
create policy "Admins update onboarding steps" on public.onboarding_steps for update to authenticated using (public.is_supertrade_admin()) with check (public.is_supertrade_admin());
drop policy if exists "Admins delete onboarding steps" on public.onboarding_steps;
create policy "Admins delete onboarding steps" on public.onboarding_steps for delete to authenticated using (public.is_supertrade_admin());

-- Seed starter content (editable from the admin UI after admin setup).
insert into public.onboarding_steps (id,title,description,video_url,action_label,action_url,guide_text,position,is_published) values
('register','Create your broker account','Register with the broker using the official link provided here.','','Open registration','','Use the registration link below. If you already have an account, continue to the next step and follow the existing-account instructions.',1,true),
('fund','How to fund your account','Follow the funding guide before making a deposit.','','Open funding page','','Check the broker’s minimum deposit and account type before sending money. Deposits go directly to your broker, not SUPERTRADE.',2,true),
('connect','Connect to copy trading','Watch the tutorial and follow each step to link your account.','','Open copy trading','','Follow the copy-trading provider’s official instructions. Confirm account details and risk settings before enabling copying.',3,true),
('withdraw','Withdrawals and account support','Find withdrawal guidance and know where to ask for help.','','Open withdrawal guide','','Review the broker’s withdrawal rules and fees. SUPERTRADE does not hold client trading funds.',4,true)
on conflict (id) do nothing;

-- IMPORTANT: after the owner has signed up and confirmed their email, run the one-time admin grant below
-- after replacing the email with the exact account email you control:
-- update public.profiles set role = 'admin' where lower(email) = lower('YOUR_OWNER_EMAIL');
-- Run that statement manually in SQL Editor as the project owner. Never expose service-role keys in frontend code.
